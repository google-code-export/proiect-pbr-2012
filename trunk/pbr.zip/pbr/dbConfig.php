<?php
	
	$host = "localhost";
	$username = "root";
	$password = "";
	$db = "pbr";
	$table = "dogs";
	$table2 = "dogs2";
	
?>
